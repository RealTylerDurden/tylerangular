import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css']
})
export class EmployeesListComponent implements OnInit {

  public employees : any[] = [];
  constructor(private employeeService : EmployeeService,private router : Router) { }
  public countEmp : number = 0;

  ngOnInit() {
    this.getEmployeesData();
 }
  

  deleteEmp(empId){   
    this.employeeService.deleteEmployee(empId).subscribe(
      (data : any[])=> this.employees = data
    );
    this.getEmployeesData();  
  }

  getEmployeesData(){
    this.employeeService.getEmployees().subscribe(
      (data : any[])=> this.employees = data
    );
  }

  editEmployee(id){  
    this.router.navigate(['/editEmployee',id])
  }

  redirectEmpDetails(empId){
    this.router.navigate(['/employeeDetail',empId]);
  }
  

}
