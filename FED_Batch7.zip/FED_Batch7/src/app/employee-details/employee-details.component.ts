import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee.service';
import {ActivatedRoute} from '@angular/router';
import {Employee } from '../employee';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  constructor(private employeeService : EmployeeService, private route : ActivatedRoute) { }

  public empId ;
  public employee = new Employee();
 
  ngOnInit() {
    //param map without using snapshot
    this.route.paramMap.subscribe( res=> {this.empId = res.get('empId')});
    this.employeeService.getEmployee(this.empId).subscribe((res : Employee) =>  this.employee = res);
    
  }
  

}