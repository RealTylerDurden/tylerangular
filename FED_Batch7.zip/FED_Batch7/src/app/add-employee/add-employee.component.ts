import { Component, OnInit } from '@angular/core';
import {Employee } from '../employee';
import {EmployeeService} from '../employee.service';
import {ActivatedRoute} from '@angular/router';
import {Router} from '@angular/router';
 
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor(private employeeService : EmployeeService, private route : ActivatedRoute, private router : Router) { }
  public employee = new Employee();
  public empId;
  public locations = ['Bangalore','Chennai','Pune','Hyderabad'];
  public isEdit : boolean = false;
  ngOnInit() {
    let id = parseInt(this.route.snapshot.paramMap.get('id'));
    this.empId = id;
    if(this.empId > 0){
      this.isEdit = true;
      this.employeeService.getEmployee(this.empId).subscribe(
        (data : Employee) => this.employee=data
      )
    }
  }
  onSubmit(){
    if(this.isEdit){
      this.employeeService.updateEmployee(this.employee).subscribe(
        (data : Employee) => this.employee=data
      );
      this.router.navigate(['/employees']);
    }else{
      this.employeeService.createEmployee(this.employee).subscribe(
        error => console.log(error)
      );
      this.router.navigate(['/employees']);
    }
    
  }


}