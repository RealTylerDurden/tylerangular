import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'employeelistFilter'
})
export class EmployeelistFilterPipe implements PipeTransform {

  transform(employees: any[], searchText: string): any[] {
    if(!employees) return [];
    if(!searchText) return employees;

    searchText = searchText.toLowerCase();

    return employees.filter(
      emp => {return emp.name.toLowerCase().includes(searchText);}
    )
    
  }

}