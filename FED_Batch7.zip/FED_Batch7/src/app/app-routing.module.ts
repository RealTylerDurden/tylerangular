import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeesListComponent } from './employees-list/employees-list.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';



const routes: Routes = [
  {path:'employees',component:EmployeesListComponent},
  {path : 'addEmployee', component : AddEmployeeComponent },
  {path : 'editEmployee/:id', component : AddEmployeeComponent },
  {path : 'details/:empId', component : EmployeeDetailsComponent }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
